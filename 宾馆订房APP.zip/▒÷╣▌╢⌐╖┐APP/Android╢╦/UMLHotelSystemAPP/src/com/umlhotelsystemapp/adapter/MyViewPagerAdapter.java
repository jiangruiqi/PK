package com.umlhotelsystemapp.adapter;

import java.util.ArrayList;
import java.util.List;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.ViewGroup;
import com.umlhotelsystemapp.fragment.MyReserveFragment;
import com.umlhotelsystemapp.fragment.ReserveFragment;

public class MyViewPagerAdapter extends FragmentPagerAdapter {
	
	private static String[] TITLES = new String[]{"预定房间","我的预定"};
	private List<Fragment> fragments = new ArrayList<Fragment>();
	
	public MyViewPagerAdapter(FragmentManager fm) {
		super(fm);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Fragment getItem(int arg0) {
		
		ReserveFragment reserveFragment = new ReserveFragment();
		MyReserveFragment myReserveFragment = new MyReserveFragment();
		
		fragments.add(reserveFragment);
		fragments.add(myReserveFragment);
		
		return fragments.get(arg0);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return TITLES.length;
	}
	
	@Override
	public CharSequence getPageTitle(int position) {
		return TITLES[position];
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		// TODO Auto-generated method stub
		super.destroyItem(container, position, object);
	}

}
