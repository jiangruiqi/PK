package com.umlhotelsystemapp.constant;

public class Constant {
	public final static String URL = "http://192.168.191.1:8080/UMLHotelSysOnline/";
	public static String username;
	public static String name;
	public static String tel;
	public static String identify;
}
