package com.umlhotelsystemapp.fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.umlhotelsystemapp.activity.R;
import com.umlhotelsystemapp.constant.Constant;
import com.umlhotelsystemapp.tools.HttpUtil;
import com.umlhotelsystemapp.tools.Reserve;

public class MyReserveFragment extends Fragment {
	
	private ListView my_reserve_listview;
	private Button my_reserve_refresh;
	private Handler handler;
	private String success_resp;
	private ProgressDialog progressDialog;
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_my_reserve, container,false);
		return view;
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		my_reserve_listview = (ListView) view.findViewById(R.id.my_reserve_listview);
		my_reserve_refresh = (Button) view.findViewById(R.id.my_reserve_refresh);
		my_reserve_refresh.setOnClickListener(refreshClick);
		
		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					progressDialog.cancel();
					Toast.makeText(getActivity(), "网络错误，查询失败", Toast.LENGTH_LONG).show();
					break;
				case 1:
					progressDialog.cancel();
					Toast.makeText(getActivity(), "当前没有任何关于您的预定信息", Toast.LENGTH_LONG).show();
					break;
				case 2:
					progressDialog.cancel();
					String[] success_resp_after = success_resp.split("##");
					Gson gson = new Gson();
					ArrayList<Reserve> list_reserve = gson.fromJson(success_resp_after[1], new TypeToken<ArrayList<Reserve>>(){}.getType());
					
					List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
					
					for(int i = 0 ; i < list_reserve.size() ; i++){
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("room_type",list_reserve.get(i).getRoomType());
						map.put("room_name",list_reserve.get(i).getRoomName());
						map.put("startTime",list_reserve.get(i).getStartTime());
						map.put("endTime",list_reserve.get(i).getEndTime());
				        list.add(map);
					}
					
					SimpleAdapter adapter = new SimpleAdapter(getActivity(),list,R.layout.listitem_my_reserve,
			                new String[]{"room_type","room_name","startTime","endTime"},
			                new int[]{R.id.listview_my_reserve_roomType,R.id.listview_my_reserve_roomName,R.id.listview_my_reserve_startTime,R.id.listview_my_reserve_endTime});
					my_reserve_listview.setAdapter(adapter);
					break;
				default:
					break;
				}
			}
		};
		
		createProgressDialog();
		
		new Thread(){
			@Override
			public void run() {
				super.run();
				
				List<NameValuePair> param = new ArrayList<NameValuePair>();
				param.add(new BasicNameValuePair("username", Constant.username));
				
				String resp = null;
				resp = HttpUtil.sendPost(Constant.URL + "SearchReserveServer", param, HTTP.UTF_8);
				
				if(resp == null){
					handler.sendEmptyMessage(0);
				}else if(resp.equals("donothaveanyserve")){
					handler.sendEmptyMessage(1);
				}else if(resp.length() > 7){
					String isSucceed = resp.substring(0,7);
					if(isSucceed.equals("success")){
						success_resp = resp;
						handler.sendEmptyMessage(2);
					}else{
						handler.sendEmptyMessage(0);
					}
				}else{
					handler.sendEmptyMessage(0);
				}
			};
		}.start();
		
	}
	
	private void createProgressDialog(){
	    progressDialog = new ProgressDialog(getActivity());
	    progressDialog.setMessage("查询中，请稍候...");
	    progressDialog.setCancelable(false);
	    progressDialog.show();
	  }
	
	OnClickListener refreshClick = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			RotateAnimation rotateAnim = new RotateAnimation(0, 720, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
			rotateAnim.setDuration(1000);
			rotateAnim.setFillAfter(true);
			my_reserve_refresh.startAnimation(rotateAnim);
			createProgressDialog();
			new Thread(){
				@Override
				public void run() {
					super.run();
					
					List<NameValuePair> param = new ArrayList<NameValuePair>();
					param.add(new BasicNameValuePair("username", Constant.username));
					
					String resp = null;
					resp = HttpUtil.sendPost(Constant.URL + "SearchReserveServer", param, HTTP.UTF_8);
					
					if(resp == null){
						handler.sendEmptyMessage(0);
					}else if(resp.equals("donothaveanyserve")){
						handler.sendEmptyMessage(1);
					}else if(resp.length() > 7){
						String isSucceed = resp.substring(0,7);
						if(isSucceed.equals("success")){
							success_resp = resp;
							handler.sendEmptyMessage(2);
						}else{
							handler.sendEmptyMessage(0);
						}
					}else{
						handler.sendEmptyMessage(0);
					}
				};
			}.start();
		}
	};

}
