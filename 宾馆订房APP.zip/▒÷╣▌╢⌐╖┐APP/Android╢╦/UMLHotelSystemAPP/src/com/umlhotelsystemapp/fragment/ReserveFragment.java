package com.umlhotelsystemapp.fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import com.umlhotelsystemapp.activity.R;
import com.umlhotelsystemapp.constant.Constant;
import com.umlhotelsystemapp.tools.HttpUtil;

public class ReserveFragment extends Fragment {
	
	private ListView room_type_listview;
	private Handler handler;
	private ProgressDialog progressDialog;
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_reserve, container,false);
		return view;
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		room_type_listview = (ListView) view.findViewById(R.id.room_type_listview);
		
		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
					case 0:
						progressDialog.cancel();
						Toast.makeText(getActivity(), "网络错误，预定失败", Toast.LENGTH_LONG).show();
						break;
					case 1:
						progressDialog.cancel();
						Toast.makeText(getActivity(), "预定成功", Toast.LENGTH_LONG).show();
						break;
					case 2:
						progressDialog.cancel();
						Toast.makeText(getActivity(), "网络错误，预定失败", Toast.LENGTH_LONG).show();
						break;
					default:
						break;
				}
			}
		};
		
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map_pt = new HashMap<String, Object>();
		map_pt.put("room_type","      普通房");
		map_pt.put("room_price","¥ 100");
        list.add(map_pt);
        Map<String, Object> map_dc = new HashMap<String, Object>();
        map_dc.put("room_type","      大床房");
        map_dc.put("room_price","¥ 120");
        list.add(map_dc);
        Map<String, Object> map_dr = new HashMap<String, Object>();
        map_dr.put("room_type","      单人房");
        map_dr.put("room_price","¥ 120");
        list.add(map_dr);
        Map<String, Object> map_hh = new HashMap<String, Object>();
        map_hh.put("room_type","      豪华套房");
        map_hh.put("room_price","¥ 200");
        list.add(map_hh);
		
		SimpleAdapter adapter = new SimpleAdapter(getActivity(),list,R.layout.listitem_room_type,
                new String[]{"room_type","room_price"},
                new int[]{R.id.room_type,R.id.room_price});
		room_type_listview.setAdapter(adapter);
		
		room_type_listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					final int position, long id) {
				// TODO Auto-generated method stub
				final AlertDialog dig = new AlertDialog.Builder(getActivity()).create();
				dig.show();
				
				final Window window = dig.getWindow();
				window.setContentView(R.layout.reserve_alert);
				
				window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM); 
				window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE); 
				
				final DatePicker datepicker = (DatePicker) window.findViewById(R.id.datepicker);
				final EditText et_days = (EditText) window.findViewById(R.id.days);
				
				LinearLayout dpContainer = (LinearLayout)datepicker.getChildAt(0)   ;   // LinearLayout  
				LinearLayout dpSpinner = (LinearLayout)dpContainer.getChildAt(0);       // 0 : LinearLayout; 1 : CalendarView  
				for(int i = 0; i < dpSpinner.getChildCount(); i ++) {  
				    NumberPicker numPicker = (NumberPicker)dpSpinner.getChildAt(i);     // 0-2 : NumberPicker  
				    LayoutParams params1 = new LayoutParams(120, LayoutParams.WRAP_CONTENT);  
				    params1.leftMargin = 0;  
				    params1.rightMargin = 30;  
				    numPicker.setLayoutParams(params1);  
				 } 

				
				Button bt_reserve = (Button) window.findViewById(R.id.bt_reserve_alert);
				bt_reserve.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						String days = et_days.getText().toString();
						
						if(days.equals("")){
							Toast.makeText(getActivity(), "请输入入住天数", Toast.LENGTH_LONG).show();
							return;
						}
						
						int year = datepicker.getYear();
						int month = datepicker.getMonth();
						int day = datepicker.getDayOfMonth();
						
						final java.sql.Timestamp startTime = new java.sql.Timestamp(System.currentTimeMillis());
						
						startTime.setYear(year - 1900);
						startTime.setMonth(month);
						startTime.setDate(day);
						
						final java.sql.Timestamp endTime = (java.sql.Timestamp) startTime.clone();
						
						endTime.setDate(startTime.getDate() + Integer.valueOf(days));
						
						new Thread(){
							@Override
							public void run() {
								super.run();
								
								List<NameValuePair> param = new ArrayList<NameValuePair>();
								param.add(new BasicNameValuePair("username", Constant.username));
								param.add(new BasicNameValuePair("room_type", String.valueOf(position)));
								param.add(new BasicNameValuePair("startTime", startTime.toString()));
								param.add(new BasicNameValuePair("endTime", endTime.toString()));
								
								String resp = null;
								resp = HttpUtil.sendPost(Constant.URL + "ReserveServer", param, HTTP.UTF_8);
								
								if(resp == null){
									handler.sendEmptyMessage(0);
								}else if(resp.equals("success")){
									handler.sendEmptyMessage(1);
								}else if(resp.equals("failed")){
									handler.sendEmptyMessage(2);
								}else{
									handler.sendEmptyMessage(0);
								}
							};
						}.start();
						
						dig.dismiss();
						
						createProgressDialog();
					}
				});
				
				Button bt_cancel = (Button) window.findViewById(R.id.bt_cancel_alert);
				bt_cancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dig.dismiss();
					}
				});
			}
		});
	}

	private void createProgressDialog(){
	    progressDialog = new ProgressDialog(getActivity());
	    progressDialog.setMessage("预定中，请稍候...");
	    progressDialog.setCancelable(false);
	    progressDialog.show();
	  }
}
