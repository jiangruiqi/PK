package com.umlhotelsystemapp.activity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import com.umlhotelsystemapp.constant.Constant;
import com.umlhotelsystemapp.tools.HttpUtil;

import android.support.v7.app.ActionBarActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends ActionBarActivity {
	
	private EditText login_username;
	private EditText login_password;
	private Button bt_login;
	private TextView register;
	private ProgressDialog progressDialog;
	private Handler handler;
	private String success_back;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login);
		
		initView();
		
		TextView test = (TextView) findViewById(R.id.test);
		test.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LoginActivity.this,MainActivity.class);
				startActivity(intent);
				LoginActivity.this.finish();
			}
		});
		
		bt_login.setOnClickListener(loginClick);
		register.setOnClickListener(registerClick);
		
		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					progressDialog.cancel();
					Toast.makeText(getApplicationContext(), "网络错误，请稍候再试", Toast.LENGTH_LONG).show();
					break;
				case 1:
					progressDialog.cancel();
					Toast.makeText(getApplicationContext(), "账号或密码错误", Toast.LENGTH_LONG).show();
					login_password.setText("");
					break;
				case 2:
					progressDialog.cancel();
					String[] success_back_after = success_back.split("##");
					Constant.name = success_back_after[1];
					Constant.identify = success_back_after[2];
					Constant.tel = success_back_after[3];
					
					Intent intent = new Intent(LoginActivity.this,MainActivity.class);
					startActivity(intent);
					LoginActivity.this.finish();
				default:
					break;
				}
			}
		};
	}

	private void initView() {
		// TODO Auto-generated method stub
		login_username = (EditText) findViewById(R.id.login_username);
		login_password = (EditText) findViewById(R.id.login_password);
		bt_login = (Button) findViewById(R.id.bt_login);
		register = (TextView) findViewById(R.id.register);
	}
	
	OnClickListener loginClick = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			final String username = login_username.getText().toString();
			final String password = login_password.getText().toString();
			
			if(username.equals("")){
				Toast.makeText(getApplicationContext(), "请输入账号", Toast.LENGTH_LONG).show();
				return;
			}
			if(password.equals("")){
				Toast.makeText(getApplicationContext(), "请输入密码", Toast.LENGTH_LONG).show();
				return;
			}
			
			createProgressDialog();
			
			new Thread(){
				@Override
				public void run() {
					super.run();
					
					List<NameValuePair> param = new ArrayList<NameValuePair>();
					param.add(new BasicNameValuePair("username", username));
					param.add(new BasicNameValuePair("password", password));
					
					String resp = null;
					resp = HttpUtil.sendPost(Constant.URL + "LoginServer", param, HTTP.UTF_8);
					
					if(resp == null){
						handler.sendEmptyMessage(0);
					}else if(resp.equals("false")){
						handler.sendEmptyMessage(1);
					}else if(resp.length() > 7){
						String issuccess = resp.substring(0, 7);
						if(issuccess.equals("success")){
							Constant.username = username;
							success_back = resp;
							handler.sendEmptyMessage(2);
						}else{
							handler.sendEmptyMessage(0);
						}
					}else{
						handler.sendEmptyMessage(0);
					}
				};
			}.start();
		}
	};
	
	OnClickListener registerClick = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
			startActivity(intent);
		}
	};
	
	private void createProgressDialog(){
	    progressDialog = new ProgressDialog(LoginActivity.this);
	    progressDialog.setMessage("登录中，请稍候...");
	    progressDialog.setCancelable(false);
	    progressDialog.show();
	  }
	
	static boolean boolKey=false;
	static long oldTime;
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event){
		
		if(keyCode==KeyEvent.KEYCODE_BACK){
			if(boolKey==false){
				Calendar c = Calendar.getInstance();  
				oldTime=c.getTimeInMillis();
				boolKey=true;
				Toast.makeText(getApplicationContext(), "再按一次返回键退出！", 3).show();
			}
			else{
				Calendar c = Calendar.getInstance();  
				long newTime=c.getTimeInMillis();
				System.out.println(newTime+"-"+oldTime+"-");
				if(newTime-oldTime<3000&&newTime-oldTime>300){
					System.exit(0);
				}else{
					boolKey=false;
					onKeyDown(keyCode,event);
				}
			}
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
