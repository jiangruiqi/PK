package com.umlhotelsystemapp.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import com.umlhotelsystemapp.constant.Constant;
import com.umlhotelsystemapp.tools.HttpUtil;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends ActionBarActivity {
	
	private EditText register_username;
	private EditText register_password;
	private EditText register_sure_password;
	private EditText register_name;
	private EditText register_tel;
	private EditText register_identify;
	private Button bt_register;
	private Handler handler;
	private ProgressDialog progressDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_register);
		
		initView();
		
		bt_register.setOnClickListener(registerClick);
		
		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case 0:
					progressDialog.cancel();
					Toast.makeText(getApplicationContext(), "网络错误，注册失败", Toast.LENGTH_LONG).show();
					break;
				case 1:
					progressDialog.cancel();
					Toast.makeText(getApplicationContext(), "注册成功", Toast.LENGTH_LONG).show();
					RegisterActivity.this.finish();
					break;
				case 2:
					progressDialog.cancel();
					Toast.makeText(getApplicationContext(), "该账号已存在，请更换账号后重新注册", Toast.LENGTH_LONG).show();
					break;
				default:
					break;
				}
			}
		};
	}

	private void initView() {
		// TODO Auto-generated method stub
		register_username = (EditText) findViewById(R.id.register_username);
		register_password = (EditText) findViewById(R.id.register_password);
		register_sure_password = (EditText) findViewById(R.id.register_sure_password);
		register_name = (EditText) findViewById(R.id.register_name);
		register_tel = (EditText) findViewById(R.id.register_tel);
		register_identify = (EditText) findViewById(R.id.register_identify);
		bt_register = (Button) findViewById(R.id.bt_register);
	}
	
	OnClickListener registerClick = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			final String username = register_username.getText().toString();
			final String password = register_password.getText().toString();
			String sure_password = register_sure_password.getText().toString();
			final String name = register_name.getText().toString();
			final String tel = register_tel.getText().toString();
			final String identify = register_identify.getText().toString();
			
			if(username.equals("")){
				Toast.makeText(getApplicationContext(), "账号不能为空", Toast.LENGTH_LONG).show();
				return;
			}
			if(password.equals("")){
				Toast.makeText(getApplicationContext(), "密码不能为空", Toast.LENGTH_LONG).show();
				return;
			}
			if(sure_password.equals("")){
				Toast.makeText(getApplicationContext(), "请确认密码", Toast.LENGTH_LONG).show();
				return;
			}
			if(!password.equals(sure_password)){
				Toast.makeText(getApplicationContext(), "两次密码不一致，请重新输入", Toast.LENGTH_LONG).show();
				register_password.setText("");
				register_sure_password.setText("");
				return;
			}
			if(name.equals("")){
				Toast.makeText(getApplicationContext(), "用户姓名不能为空", Toast.LENGTH_LONG).show();
				return;
			}
			if(tel.equals("")){
				Toast.makeText(getApplicationContext(), "电话不能为空", Toast.LENGTH_LONG).show();
				return;
			}
			if(identify.equals("")){
				Toast.makeText(getApplicationContext(), "身份证号不能为空", Toast.LENGTH_LONG).show();
				return;
			}
			
			createProgressDialog();
			
			new Thread(){
				@Override
				public void run() {
					super.run();
					
					List<NameValuePair> param = new ArrayList<NameValuePair>();
					param.add(new BasicNameValuePair("user_login_name", username));
					param.add(new BasicNameValuePair("password", password));
					param.add(new BasicNameValuePair("user_name", name));
					param.add(new BasicNameValuePair("user_card", identify));
					param.add(new BasicNameValuePair("user_tele", tel));
					
					String resp = null;
					resp = HttpUtil.sendPost(Constant.URL + "RegistServer", param, HTTP.UTF_8);
					
					if(resp == null){
						handler.sendEmptyMessage(0);
					}else if(resp.equals("true")){
						handler.sendEmptyMessage(1);
					}else if(resp.equals("false")){
						handler.sendEmptyMessage(2);
					}else{
						handler.sendEmptyMessage(0);
					}
					
				};
			}.start();
		}
	};
	
	private void createProgressDialog(){
	    progressDialog = new ProgressDialog(RegisterActivity.this);
	    progressDialog.setMessage("注册中，请稍候...");
	    progressDialog.setCancelable(false);
	    progressDialog.show();
	  }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
