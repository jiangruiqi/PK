package com.umlhotelsystemapp.activity;

import java.util.Calendar;

import android.os.Bundle;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Toast;

import com.umlhotelsystemapp.adapter.MyViewPagerAdapter;

public class MainActivity extends ActionBarActivity {
	
	private ViewPager viewPager;
	private PagerTabStrip pagerTabStrip;
	private MyViewPagerAdapter myViewPagerAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		
		initView();
		
		pagerTabStrip.setTabIndicatorColor(getResources().getColor(android.R.color.holo_blue_light));
		pagerTabStrip.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));
		pagerTabStrip.setTextColor(getResources().getColor(android.R.color.white));
		
		viewPager.setAdapter(myViewPagerAdapter);
	}

	private void initView() {
		// TODO Auto-generated method stub
		viewPager = (ViewPager)findViewById(R.id.viewPager);
		viewPager.setOffscreenPageLimit(2);
		pagerTabStrip = (PagerTabStrip) findViewById(R.id.pagerTabStrip);
		myViewPagerAdapter = new MyViewPagerAdapter(getSupportFragmentManager());
	}
	
	static boolean boolKey=false;
	static long oldTime;
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event){
		
		if(keyCode==KeyEvent.KEYCODE_BACK){
			if(boolKey==false){
				Calendar c = Calendar.getInstance();  
				oldTime=c.getTimeInMillis();
				boolKey=true;
				Toast.makeText(getApplicationContext(), "再按一次返回键退出！", 3).show();
			}
			else{
				Calendar c = Calendar.getInstance();  
				long newTime=c.getTimeInMillis();
				System.out.println(newTime+"-"+oldTime+"-");
				if(newTime-oldTime<3000&&newTime-oldTime>300){
					System.exit(0);
				}else{
					boolKey=false;
					onKeyDown(keyCode,event);
				}
			}
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
