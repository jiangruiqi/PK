package org.hotel.server.model;

public class Room {
	private String roomName;
	private int roomId;
	private String roomType;
	private float roomPrice;

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public float getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(float roomPrice) {
		this.roomPrice = roomPrice;
	}

	public Room(String roomName, int roomId, String roomType, float roomPrice) {
		super();
		this.roomName = roomName;
		this.roomId = roomId;
		this.roomType = roomType;
		this.roomPrice = roomPrice;
	}

}
