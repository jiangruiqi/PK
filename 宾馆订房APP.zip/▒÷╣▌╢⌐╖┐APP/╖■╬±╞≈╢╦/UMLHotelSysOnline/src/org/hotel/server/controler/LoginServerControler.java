package org.hotel.server.controler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hotel.dbmanager.DBConn;
import org.hotel.server.model.User;

public class LoginServerControler {
	private static LoginServerControler loginServerControler;
	private DBConn dbConn;

	private LoginServerControler() {
		dbConn = new DBConn();
	}

	public static synchronized LoginServerControler getInstance() {
		if (loginServerControler == null) {
			loginServerControler = new LoginServerControler();
		}
		return loginServerControler;
	}

	public boolean Login(String username, String password) {
		String sql = "SELECT * FROM tb_user WHERE user_login_name = ? AND user_password = ? ";
		Connection connection = (Connection) dbConn.getConntion();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			resultSet = dbConn.execQuery(preparedStatement);
			if (resultSet.next()) {
				//System.out.println("LOGIN SUCCESS");
				return true;
			} else {
				//System.out.println("LOGIN FAILED");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			//System.out.println("ִ��finally");
			DBConn.closeConn(connection, preparedStatement, resultSet);
		}
		return false;
	}

	public static void main(String[] args) {
		LoginServerControler controler = LoginServerControler.getInstance();
		controler.Login("admintest", "123456");
		controler.Login("admintest", "1256");
	}

	public User findUserInfo(String user_login_name) {
		String sql = "SELECT * FROM tb_user WHERE user_login_name = ?";
		Connection connection = (Connection) dbConn.getConntion();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user_login_name);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				String user_name = resultSet.getString("user_name");
				String user_card = resultSet.getString("user_card");
				String user_tele = resultSet.getString("user_tele");
				return new User(user_name, user_card, user_tele);
			} else {
				return null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			//System.out.println("ִ��finnale");
			DBConn.closeConn(connection, preparedStatement, resultSet);
		}
	}
}
