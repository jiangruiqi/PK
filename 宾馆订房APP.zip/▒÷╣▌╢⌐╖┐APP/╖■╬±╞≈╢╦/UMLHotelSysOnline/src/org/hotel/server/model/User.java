package org.hotel.server.model;

public class User {
	private String username;
	private String usercard;
	private String usertele;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsercard() {
		return usercard;
	}
	public void setUsercard(String usercard) {
		this.usercard = usercard;
	}
	public String getUsertele() {
		return usertele;
	}
	public void setUsertele(String usertele) {
		this.usertele = usertele;
	}
	public User(String username, String usercard, String usertele) {
		super();
		this.username = username;
		this.usercard = usercard;
		this.usertele = usertele;
	}
	
}
