package org.hotel.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hotel.server.controler.RegistServerControler;

public class RegistServer extends HttpServlet {

	private RegistServerControler registServerControler;

	/**
	 * Constructor of the object.
	 */
	public RegistServer() {
		super();
		registServerControler = RegistServerControler.getInstance();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		String user_login_name = request.getParameter("user_login_name");
		String password = request.getParameter("password");
		String user_name = request.getParameter("user_name");
		String user_card = request.getParameter("user_card");
		String user_tele = request.getParameter("user_tele");
		if (user_login_name == null || password == null || user_name == null
				|| user_card == null || user_tele == null) {
			out.write(false + "");
			return;
		}
		boolean issuccessful = registServerControler.registUserByInfo(user_login_name, password, user_name, user_card, user_tele);
		out.write(issuccessful + "");
		return;
		
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
