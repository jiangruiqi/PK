package org.hotel.server.controler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hotel.dbmanager.DBConn;

public class RegistServerControler {
	private static RegistServerControler registServerControler;
	private DBConn dbConn;

	private RegistServerControler() {
		dbConn = new DBConn();
	}

	public static synchronized RegistServerControler getInstance() {
		if (registServerControler == null) {
			registServerControler = new RegistServerControler();
		}
		return registServerControler;
	}

	public boolean registUserByInfo(String user_login_name, String password,
			String user_name, String user_card, String user_tele) {
		String sql = "INSERT INTO tb_user(user_login_name,user_password,user_name,user_card,user_tele,user_custom) VALUES (?,?,?,?,?,?)";
		String sql2 = "INSERT INTO tb_custom(custom_name,custom_id_card_num,custom_tele_num) VALUES (?,?,?)";
		String sql3 = "SELECT * FROM tb_custom WHERE custom_name= ? AND custom_id_card_num= ? AND custom_tele_num =?";
		String sql4 = "DELETE FROM tb_custom WHERE custom_id = ? ";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			connection = dbConn.getConntion();
			// �������ݵ�custom��
			preparedStatement = connection.prepareStatement(sql2);
			preparedStatement.setString(1, user_name);
			preparedStatement.setString(2, user_card);
			preparedStatement.setString(3, user_tele);
			int issucc = preparedStatement.executeUpdate();
			int customId = -1;
			if (issucc != 0) {
				preparedStatement = connection.prepareStatement(sql3);
				preparedStatement.setString(1, user_name);
				preparedStatement.setString(2, user_card);
				preparedStatement.setString(3, user_tele);
				resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					customId = resultSet.getInt("custom_id");
				} else {
					System.out.println("����ʧ��");
					return false;
				}

				while (resultSet.next()) {
					preparedStatement = connection.prepareStatement(sql4);
					preparedStatement.setInt(1, resultSet.getInt("custom_id"));
					preparedStatement.execute();
				}
			} else {
				System.out.println("����ʧ��2");
				return false;
			}

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user_login_name);
			preparedStatement.setString(2, password);
			preparedStatement.setString(3, user_name);
			preparedStatement.setString(4, user_card);
			preparedStatement.setString(5, user_tele);
			preparedStatement.setInt(6, customId);
			int changeRow = preparedStatement.executeUpdate();
			// int changeRow = preparedStatement.executeUpdate();
			if (changeRow == 0) {
				System.out.println("ע��ʧ��");
				return false;
			} else {
				System.out.println("ע��ɹ�");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBConn.closeConn(connection, preparedStatement, null);
		}
		return false;
	}
}
