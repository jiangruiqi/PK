package org.hotel.server.model;

public class Reserve {
	private int reserveId;
	private String startTime;
	private String endTime;
	private String roomName;
	private String roomType;
	public int getReserveId() {
		return reserveId;
	}
	public void setReserveId(int reserveId) {
		this.reserveId = reserveId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Reserve(int reserveId, String startTime, String endTime,
			String roomName, String roomType) {
		super();
		this.reserveId = reserveId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.roomName = roomName;
		this.roomType = roomType;
	}
	
}
