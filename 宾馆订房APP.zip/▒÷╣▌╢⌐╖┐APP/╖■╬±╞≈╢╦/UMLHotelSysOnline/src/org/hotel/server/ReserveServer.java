package org.hotel.server;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hotel.server.controler.ReserveServerControler;

public class ReserveServer extends HttpServlet {
	
	private ReserveServerControler reserveServerControler;

	/**
	 * Constructor of the object.
	 */
	public ReserveServer() {
		super();
		reserveServerControler = ReserveServerControler.getInstance();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String username = request.getParameter("username");
		int room_type = Integer.valueOf(request.getParameter("room_type"));
		String startTime =  request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		
		Timestamp startTimestamp = Timestamp.valueOf(startTime);
		Timestamp endTimestamp = Timestamp.valueOf(endTime);
		
		boolean result = reserveServerControler.addReserve(username, room_type, startTimestamp, endTimestamp);
		
		if(result == true){
			out.write("success");
		}else{
			out.write("failed");
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
