package org.hotel.server.controler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hotel.bean.TbRoom;
import org.hotel.dbmanager.DBConn;
import org.hotel.server.model.Reserve;
import org.hotel.server.tools.DBUtil;

public class ReserveServerControler {
	private static ReserveServerControler reserveServerControler;
	private static DBConn dbconn;

	private ReserveServerControler() {
		dbconn = new DBConn();
	}

	public static synchronized ReserveServerControler getInstance() {
		if (reserveServerControler == null) {
			reserveServerControler = new ReserveServerControler();
		}
		return reserveServerControler;
	}

	public static boolean addReserve(String user_login_name, int room_type,
			Timestamp startTime, Timestamp endTime) {
		String sql = "INSERT INTO tb_reserve(reserve_room_id, reserve_start_time , reserve_end_time , reserve_custom_id,reserve_create_account_id) VALUES (?,?,?,?,?)";
		String sql2 = "UPDATE tb_room SET room_cur_state  = 1 WHERE room_id = ?";
		String sql3 = "SELECT * FROM tb_user WHERE user_login_name = ?";
		Connection connection = (Connection) dbconn.getConntion();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			preparedStatement = connection.prepareStatement(sql3);
			preparedStatement.setString(1, user_login_name);
			resultSet = preparedStatement.executeQuery();
			String user_tele = null;
			String user_card = null;
			int custom_id = 0;
			String user_name = null;
			if (resultSet.next()) {
				user_name = resultSet.getString("user_name");
				user_card = resultSet.getString("user_card");
				user_tele = resultSet.getString("user_tele");
				custom_id = resultSet.getInt("user_custom");
			} else {
				return false;
			}
			
			List<TbRoom> canUsedRoom = getFreeRoom(room_type,endTime,startTime);
			
			System.out.println(canUsedRoom.toString());

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, canUsedRoom.get(0).getRoomId());
			preparedStatement.setString(2, startTime.toString());
			preparedStatement.setString(3, endTime.toString());
			preparedStatement.setInt(4, custom_id);
			preparedStatement.setInt(5, 1);
			int changeRow = preparedStatement.executeUpdate();
			if (changeRow == 0) {
				return false;
			}
			preparedStatement = connection.prepareStatement(sql2);
			preparedStatement.setInt(1, canUsedRoom.get(0).getRoomId());
			return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			DBConn.closeConn(connection, preparedStatement, resultSet);
		}
	}

	public ArrayList<Reserve> getAllReservesByCustom(String user_login_name) {
		String sql = "SELECT * FROM tb_reserve WHERE reserve_custom_id = ?";
		String sql3 = "SELECT * FROM tb_user WHERE user_login_name = ?";
		String sql2 = "SELECT * FROM tb_room WHERE room_id = ?";
		String sql4 = new String(
				"SELECT re.reserve_id, re.reserve_start_time,re.reserve_end_time,ro.room_type,ro.room_name "
						+ "FROM tb_reserve AS re,tb_room AS ro,tb_user AS us "
						+ "WHERE re.reserve_custom_id = us.user_custom AND re.reserve_room_id = ro.room_id AND us.user_login_name = ?");
		Connection connection = (Connection) dbconn.getConntion();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<Reserve> arrayList = new ArrayList<Reserve>();

		try {
			preparedStatement = connection.prepareStatement(sql4);
			preparedStatement.setString(1, user_login_name);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				int reserve_id = resultSet.getInt("reserve_id");
				String start_time = resultSet.getString("reserve_start_time");
				String end_time = resultSet.getString("reserve_end_time");
				int room_type = resultSet.getInt("room_type");
				String room_name = resultSet.getString("room_name");
				Reserve reserve = new Reserve(
						reserve_id,
						start_time,
						end_time,
						room_name,
						org.hotel.server.constante.Constant.ROOM_TYPE[room_type]);
				arrayList.add(reserve);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBConn.closeConn(connection, preparedStatement, resultSet);
		}

		return arrayList;

	}
	
	public static List<TbRoom> getFreeRoom(int room_type, Timestamp endtime_reserve,
			Timestamp starttime_reserve) {
		
		Connection conn = DBUtil.open();
		
		String sql_allRoom = "SELECT * FROM tb_room WHERE room_type = ?";

		String is_reserve = "SELECT reserve_id FROM tb_reserve WHERE ( reserve_room_id = %d AND UNIX_TIMESTAMP(reserve_start_time) > UNIX_TIMESTAMP( '%s' ) AND UNIX_TIMESTAMP(reserve_start_time) < UNIX_TIMESTAMP('%s'))OR (reserve_room_id = %d AND UNIX_TIMESTAMP(reserve_end_time) > UNIX_TIMESTAMP('%s') AND UNIX_TIMESTAMP(reserve_end_time) < UNIX_TIMESTAMP('%s'))OR (reserve_room_id = %d AND UNIX_TIMESTAMP(reserve_start_time) < UNIX_TIMESTAMP( '%s') AND UNIX_TIMESTAMP(reserve_end_time) > UNIX_TIMESTAMP( '%s'))";

		List<TbRoom> allRooms = new ArrayList<TbRoom>();
		List<TbRoom> canUsedRooms = new ArrayList<TbRoom>();
		
		try {
			PreparedStatement pstmt_select_allRoom = conn.prepareStatement(sql_allRoom);
			pstmt_select_allRoom.setInt(1, room_type);
			ResultSet rs_select_allRoom = pstmt_select_allRoom.executeQuery();
			while(rs_select_allRoom.next()){
				TbRoom tbRoom = new TbRoom();
				tbRoom.setRoomId(rs_select_allRoom.getInt(1));
				tbRoom.setRoomName(rs_select_allRoom.getString(2));
				tbRoom.setRoomType(rs_select_allRoom.getInt(3));
				tbRoom.setRoomPrice(rs_select_allRoom.getLong(4));
				tbRoom.setRoomUseable(rs_select_allRoom.getInt(5));
				tbRoom.setRoomCurState(rs_select_allRoom.getInt(6));
				
				allRooms.add(tbRoom);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBUtil.close(conn);
		}
		
		for (int i = 0; i < allRooms.size(); i++) {
			TbRoom tbRoom = allRooms.get(i);
			if (tbRoom.getRoomCurState() == 2 || tbRoom.getRoomCurState() == 3) {
				allRooms.remove(i);
			}
		}

		for (int i = 0; i < allRooms.size(); i++) {
			
			String querySql = String.format(is_reserve, allRooms.get(i)
					.getRoomId(), starttime_reserve, endtime_reserve, allRooms
					.get(i).getRoomId(), starttime_reserve, endtime_reserve,
					allRooms.get(i).getRoomId(), starttime_reserve,endtime_reserve
					);
			
			try {
				PreparedStatement pstmt = conn.prepareStatement(querySql);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next()){
					continue;
				}else{
					canUsedRooms.add(allRooms.get(i));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBUtil.close(conn);
			}
			
		}
		
		System.out.println("use room length : " + canUsedRooms.size());
		DBUtil.close(conn);
		return canUsedRooms;
	}

	// public ArrayList<Room> getUseableRoomList(Timestamp startTime,
	// Timestamp endTime, int houseType) {
	// String sql = "SELECT * FROM tb_room WHERE room_type = ?";
	// String sql2 = "SELECT * FROM tb_reserve WHERE reserve_room_id = ?";
	// Connection connection = null;
	// PreparedStatement preparedStatement = null;
	// ResultSet resultSet = null;
	// ArrayList<Room> res = new ArrayList<Room>();
	//
	// try {
	// preparedStatement = connection.prepareStatement(sql);
	// preparedStatement.setInt(1, houseType);
	// resultSet = preparedStatement.executeQuery();
	// while (resultSet.next()) {
	// int roomId = resultSet.getInt("room_id");
	// String roomName = resultSet.getString("room_name");
	// float roomPrice = resultSet.getFloat("room_price");
	// int roomUseable = resultSet.getInt("room_useable");
	// int roomCurState = resultSet.getInt("room_cur_state");
	// if (roomCurState == 3 || roomUseable == 0) {
	// break;
	// }
	// Room room = new Room(
	// roomName,
	// roomId,
	// org.hotel.server.constante.Constant.ROOM_TYPE[houseType],
	// roomPrice);
	// res.add(room);
	// }
	//
	// for(int i = 0 ; i < res.size() ; i++){
	// Room room = res.get(i);
	// preparedStatement = connection.prepareStatement(sql2);
	// preparedStatement.setInt(1, x)
	//
	// }
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// return res;
	// }

}
