package org.hotel.server.constante;

public class Constant {
	public static String[] ROOM_TYPE = new String[]{"普通房","大床房","单人房","豪华套房"};
}